# import openai
# import os

# openai.api_key = os.getenv("OPENAI_API_KEY")  # Set your key in environment
# # from openai import OpenAI
# # import os

# # client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# def get_ai_response(prompt):
#     """
#     Sends user query to OpenAI API and gets text response.
#     """
#     response = openai.ChatCompletion.create(
#         model="gpt-4o-mini",
#         messages=[
#             {"role": "system", "content": "You are Loop AI, a hospital assistant."},
#             {"role": "user", "content": prompt}
#         ],
#         temperature=0
#     )
#     return response['choices'][0]['message']['content']
from groq import Groq
import os

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def get_ai_response(prompt):
    response = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=[
            {"role": "system", "content": "You are Loop AI, a hospital assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content
