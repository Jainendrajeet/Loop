import pandas as pd

class HospitalDB:
    def __init__(self, csv_path="hospitals.csv"):
        self.df = pd.read_csv(csv_path)
        self.df['name_lower'] = self.df['Hospital'].str.lower()
        self.df['city_lower'] = self.df['City'].str.lower()

    def find_hospitals_by_city(self, city_name, limit=3):
        city = city_name.lower()
        results = self.df[self.df['city_lower'] == city]
        return results[['name', 'address']].head(limit).to_dict(orient='records')

    def check_hospital_in_network(self, hospital_name, city_name):
        name = hospital_name.lower()
        city = city_name.lower()
        match = self.df[(self.df['name_lower'] == name) & (self.df['city_lower'] == city)]
        return not match.empty
