import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")  # Set your key in environment

def get_ai_response(prompt):
    """
    Sends user query to OpenAI API and gets text response.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are Loop AI, a hospital assistant."},
            {"role": "user", "content": prompt}
        ],
        temperature=0
    )
    return response['choices'][0]['message']['content']
