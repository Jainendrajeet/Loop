from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from loop_app.hospital_db import HospitalDB
from loop_app.voice_agent import get_ai_response


app = FastAPI()
db = HospitalDB()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/query")
async def handle_query(user_query: str = Form(...)):
    # Check if query mentions hospitals in Bangalore
    if "around bangalore" in user_query.lower():
        hospitals = db.find_hospitals_by_city("Bangalore", limit=3)
        response_text = "Here are 3 hospitals around Bangalore:\n" + "\n".join([h['name'] for h in hospitals])
    elif "confirm if" in user_query.lower():
        # Example: "Can you confirm if Manipal Sarjapur in Bangalore is in my network?"
        parts = user_query.lower().split("if ")[1].split(" in ")
        hospital_name = parts[0].strip()
        city_name = parts[1].split(" is")[0].strip()
        exists = db.check_hospital_in_network(hospital_name, city_name)
        response_text = f"{hospital_name.title()} is {'in' if exists else 'not in'} your network."
    else:
        # Fallback to AI for general responses
        response_text = get_ai_response(user_query)
    
    return JSONResponse({"response": response_text})
