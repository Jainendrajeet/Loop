import csv
import sqlite3
import sys
from pathlib import Path

CSV_PATH = Path(__file__).resolve().parents[1] / "hospital_data.csv"
DB_PATH = Path(__file__).resolve().parent / "hospitals.db"

def normalize_text(s):
    return s.strip()

def create_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DROP TABLE IF EXISTS hospitals")
    cur.execute("""
    CREATE TABLE hospitals_meta (
        id INTEGER PRIMARY KEY,
        name TEXT,
        address TEXT,
        city TEXT,
        state TEXT,
        pincode TEXT,
        raw_line TEXT
    )""")
    cur.execute("CREATE VIRTUAL TABLE hospitals USING fts5(name, address, city, state, pincode, raw_line, content='hospitals_meta', tokenize='porter');")
    conn.commit()
    return conn, cur

def ingest_csv():
    if not CSV_PATH.exists():
        print("CSV file not found:", CSV_PATH)
        sys.exit(1)
    conn, cur = create_db()
    with open(CSV_PATH, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = normalize_text(row.get('name','') or row.get('Name','') or '')
            address = normalize_text(row.get('address','') or row.get('Address','') or '')
            city = normalize_text(row.get('city','') or row.get('City','') or '')
            state = normalize_text(row.get('state','') or row.get('State','') or '')
            pincode = normalize_text(row.get('pincode','') or row.get('Pincode','') or '')
            raw = str(row)
            cur.execute("INSERT INTO hospitals_meta (name,address,city,state,pincode,raw_line) VALUES (?,?,?,?,?,?)",
                        (name,address,city,state,pincode,raw))
            last_id = cur.lastrowid
            cur.execute("INSERT INTO hospitals (rowid, name, address, city, state, pincode, raw_line) VALUES (?,?,?,?,?,?,?)",
                        (last_id, name, address, city, state, pincode, raw))
    conn.commit()
    conn.close()
    print("Ingestion done. DB:", DB_PATH)

if __name__ == "__main__":
    ingest_csv()
