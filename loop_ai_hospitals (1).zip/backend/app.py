import os
import io
import sqlite3
import json
from flask import Flask, request, jsonify, send_file
from dotenv import load_dotenv
import requests
from pydub import AudioSegment

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TTS_API_KEY = os.getenv("TTS_API_KEY")

DB_PATH = os.path.join(os.path.dirname(__file__), "hospitals.db")
app = Flask(__name__, static_folder="../frontend", template_folder="../frontend")

def db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def search_hospitals_by_city(city, limit=3):
    conn = db_connection()
    cur = conn.cursor()
    q = "SELECT rowid, name, address, city, state, pincode FROM hospitals WHERE city MATCH ? LIMIT ?"
    cur.execute(q, (city, limit))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def search_hospitals_by_keywords(qtext, limit=5):
    conn = db_connection()
    cur = conn.cursor()
    safe_q = qtext.replace('"', '')
    cur.execute("SELECT rowid, name, address, city, state, pincode FROM hospitals WHERE hospitals MATCH ? LIMIT ?", (safe_q, limit))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def exact_match_hospital(name, city=None):
    conn = db_connection()
    cur = conn.cursor()
    if city:
        cur.execute("SELECT rowid, name, address, city, state, pincode FROM hospitals WHERE name = ? AND city = ? LIMIT 1", (name, city))
    else:
        cur.execute("SELECT rowid, name, address, city, state, pincode FROM hospitals WHERE name = ? LIMIT 1", (name,))
    r = cur.fetchone()
    conn.close()
    return dict(r) if r else None

@app.route("/api/ask", methods=["POST"])
def api_ask():
    data = request.get_json()
    query = data.get("query","").strip()
    if not query:
        return jsonify({"error":"empty query"}), 400

    lower = query.lower()
    scope_keywords = ['hospital','clinic','network','near','around','city','in','nearby','location','address']
    if not any(k in lower for k in scope_keywords):
        return jsonify({
            "out_of_scope": True,
            "reply": "I'm sorry, I can't help with that. I am forwarding this to a human agent."
        })

    import re
    number_search = re.search(r'(\d+).*hospital', lower)
    if "around" in lower or "near" in lower or "nearby" in lower:
        city_match = re.search(r'around ([A-Za-z ]+)', lower) or re.search(r'near ([A-Za-z ]+)', lower) or re.search(r'in ([A-Za-z ]+)', lower)
        city = city_match.group(1).strip() if city_match else None
        num = int(number_search.group(1)) if number_search else 3
        results = search_hospitals_by_city(city, limit=num) if city else search_hospitals_by_keywords("hospital", limit=num)
        reply_text = f"I found the following {len(results)} hospitals in {city or 'your area'}:\n" + "".join([f"{i+1}. {r['name']}, {r['address']}, {r.get('city','')}\n" for i,r in enumerate(results)])
        return jsonify({"out_of_scope": False, "reply": reply_text, "results": results})

    confirm_match = re.search(r'(is|confirm|am i|check).*(in my network|in network|in the network|in our network)', lower)
    if confirm_match:
        name = re.sub(r'.*(is|confirm|check)\s+','', lower)
        name = re.sub(r'(in my network|in network|in the network|in our network)\s*\?*','', name).strip()
        city_search = re.search(r'in ([A-Za-z ]+)', lower)
        city = city_search.group(1).strip() if city_search else None
        match = exact_match_hospital(name.title(), city=city.title() if city else None)
        if match:
            reply_text = f"Yes — {match['name']} in {match['city']} is in your network. Address: {match['address']}."
            return jsonify({"out_of_scope": False, "reply": reply_text, "found": True, "result": match})
        else:
            fuzzy = search_hospitals_by_keywords(name, limit=5)
            if fuzzy:
                reply_text = f"I couldn't find an exact match. I found these possible matches:\n" + "".join([f"- {r['name']}, {r['address']}, {r.get('city','')}\n" for r in fuzzy])
                return jsonify({"out_of_scope": False, "reply": reply_text, "found": False, "candidates": fuzzy})
            else:
                reply_text = "I couldn't find that hospital in the network."
                return jsonify({"out_of_scope": False, "reply": reply_text, "found": False})

    results = search_hospitals_by_keywords(query, limit=5)
    reply_text = "Here are the top matches I found:\n" + "".join([f"{i+1}. {r['name']} — {r['address']} ({r.get('city','')})\n" for i,r in enumerate(results)]) if results else "Sorry, I couldn't find matching hospitals in the network."
    return jsonify({"out_of_scope": False, "reply": reply_text, "results": results})

@app.route("/api/transcribe", methods=["POST"])
def api_transcribe():
    f = request.files.get('audio')
    if not f:
        return jsonify({"error":"no file uploaded"}), 400
    audio_bytes = f.read()
    if OPENAI_API_KEY:
        files = {"file": ("audio.wav", audio_bytes)}
        headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
        resp = requests.post("https://api.openai.com/v1/audio/transcriptions",
                             headers=headers,
                             files=files,
                             data={"model": "whisper-1"})
        if resp.status_code == 200:
            txt = resp.json().get("text","")
            return jsonify({"text": txt})
        else:
            return jsonify({"error":"transcription failed", "details": resp.text}), 500
    else:
        return jsonify({"error":"No STT API configured. Set OPENAI_API_KEY or another provider."}), 400

@app.route("/api/tts", methods=["POST"])
def api_tts():
    data = request.get_json()
    text = data.get("text","")
    if not text:
        return jsonify({"error":"empty text"}), 400
    from pydub import AudioSegment
    import io
    if TTS_API_KEY is None:
        silent = AudioSegment.silent(duration=800)
        buf = io.BytesIO()
        silent.export(buf, format="wav")
        buf.seek(0)
        return send_file(buf, mimetype="audio/wav", as_attachment=False, download_name="reply.wav")
    else:
        return jsonify({"error":"TTS provider integration required - implement with your API"}), 501

@app.route("/")
def index():
    return app.send_static_file("index.html")

if __name__ == "__main__":
    app.run(debug=True, port=5000)
