# Loop AI Hospital Network Assistant

## Overview
Small Flask + JS app.
