let micBtn = document.getElementById('micBtn');
let label = document.getElementById('label');
let transcriptDiv = document.getElementById('transcript');
let assistantDiv = document.getElementById('assistant');

let mediaRecorder;
let audioChunks = [];
let listening = false;

micBtn.onclick = async () => {
  if (!listening) {
    await startRecording();
  } else {
    await stopRecording();
  }
}

async function startRecording() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  mediaRecorder = new MediaRecorder(stream);
  audioChunks = [];
  mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
  mediaRecorder.onstop = async () => {
    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
    let fd = new FormData();
    fd.append('audio', audioBlob, 'speech.webm');
    transcriptDiv.textContent = "Transcribing...";
    const tResp = await fetch('/api/transcribe', { method: 'POST', body: fd });
    const tjson = await tResp.json();
    if (tjson.text) {
      transcriptDiv.textContent = "You: " + tjson.text;
      assistantDiv.textContent = "Loop AI (thinking)...";
      const askResp = await fetch('/api/ask', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({query: tjson.text})
      });
      const ajson = await askResp.json();
      assistantDiv.textContent = "Loop AI: " + (ajson.reply || JSON.stringify(ajson));
      const ttsResp = await fetch('/api/tts', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({text: ajson.reply || "Sorry, no reply."})
      });
      if (ttsResp.ok && ttsResp.headers.get('content-type').includes('audio')) {
        const audioData = await ttsResp.arrayBuffer();
        const audioUrl = URL.createObjectURL(new Blob([audioData], {type:'audio/wav'}));
        const audioEl = new Audio(audioUrl);
        audioEl.play();
      }
    } else {
      transcriptDiv.textContent = "Transcription error: " + JSON.stringify(tjson);
    }
  };
  mediaRecorder.start();
  listening = true;
  label.textContent = "Stop Conversation";
  micBtn.textContent = "⏹️";
}

async function stopRecording() {
  if (mediaRecorder && mediaRecorder.state !== 'inactive') {
    mediaRecorder.stop();
    listening = false;
    label.textContent = "Start Conversation";
    micBtn.textContent = "🎤";
  }
}
