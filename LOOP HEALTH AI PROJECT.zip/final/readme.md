# TO RUN THE CODE 
pip install -r requirements.txt 

uvicorn loop_app.main:app --reload --port 8001
